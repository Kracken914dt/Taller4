
package modelo;

public class Ecuacion{
    private int a;
    private int b;
    private int c;
    private int E;
    
    public int geta(){
        return a;}
    public void seta(int a){
        this.a = a;}
    public int getb(){
        return b;}
    public void setb(int b){
        this.b = b;}
    public int getc(){
        return c;}
    public void setc(int c){
        this.c = c;}
    public int gety(){
        return E;}
    public void sety(int y){
        this.E= E;} 
    public Ecuacion(int a, int b, int c, int E){
        this.a = a;
        this.b = b;
        this.c = c;
        this.E = E;
    }
    public int getx(){
        int x = a*(E*E^2)+b*E+c;
        return x;
    }
    public String elString(){
        return "La ecuacion x es = ("+ a + ")("+ b + "^2)+(" + b + ")(" + E + ")+" + c + " Este es el valor de X "+getx();
    }
    
}
