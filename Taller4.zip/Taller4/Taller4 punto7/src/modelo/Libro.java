package modelo;

public class Libro {
// ATRIBUTOS DE INSTANCIA 
    private String titulo, primerNombre, segundoNombre, primerApellido, ISBN, paginas, edicion, ciudad, pais, fecha_de_edicion;
    
     // ATRIBUTO DE CLASE
    public static String editorial = "Prentice-Hall";
    
    //METODO CONSTRUCTOR POR DEFECTO
    public Libro(){
        
    }
    // METODOS GETTER
    public String getTitulo() {
        return this.titulo;
    }
    public String getPrimerNombre(){
        return this.primerNombre;
    }
    public String getSegundoNombre(){
        return this.segundoNombre;
    }
    public String getPrimerApellido(){
        return this.primerApellido;
    }
    public String getISBN(){
        return this.ISBN;
    }
    public String getPaginas(){
        return this.paginas;
    }
    public String getEdicion(){
        return this.edicion;
    }
    public String getCiudad(){
        return this.ciudad;
    }
    public String getPais(){
        return this.pais;
    }
    public String getFechasEdicion(){
        return this.fecha_de_edicion;
    }
    //METODOS SETTER
    public void setTitulo(String titulo){
        this.titulo = titulo;
    }
    public void setPrimerNombre(String primerNombre){
        this.primerNombre = primerNombre;
    }
    public void setSegundoNombre(String segundoNombre){
        this.segundoNombre = segundoNombre;
    }
    public void setPrimerApellido(String primerApellido){
        this.primerApellido = primerApellido;
    }
    public void setISBN(String ISBN){
        this.ISBN = ISBN;
    }
    public void setPaginas(String paginas){
        this.paginas = paginas;
    }
    public void setEdicion(String edicion ){
        this.edicion = edicion;
    }
    public void setCiudad(String ciudad){
        this.ciudad = ciudad;
    }
    public void setPais(String pais){
        this.pais = pais;
    }
    public void setFechasEdicion(String fecha_de_edicion){
        this.fecha_de_edicion = fecha_de_edicion;
    }
    

}
