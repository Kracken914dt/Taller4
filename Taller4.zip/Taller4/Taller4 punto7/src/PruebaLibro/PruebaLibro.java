package PruebaLibro;
import modelo.*;
import java.util.Scanner;
public class PruebaLibro {
    public static void main(String[] args) {
        leer();
    } 
    
    public static void  leer() {
        for (int i = 0; i < 5; i++) {
            Libro libro = new Libro();
            Scanner Leer = new Scanner(System.in);
            System.out.println("Introduzca el titulo de su libro: ");
            String titulo = Leer.nextLine();

            System.out.println("Introduzca su primer nombre: ");
            String primerNombre = Leer.nextLine();

            System.out.println("Introduzca su segundo nombre: ");
            String SegundoNombre = Leer.nextLine();

            System.out.println("introduzca su primer apellido: ");
            String primerapellido = Leer.nextLine();

            System.out.println("Introduzca el ISBN: ");
            String ISBN = Leer.nextLine();

            System.out.println("Introduca la edicion: ");
            String edicion = Leer.nextLine();

            System.out.println("Introduca la ciudad: ");
            String ciudad = Leer.nextLine();

            System.out.println("Introduca el pais: ");
            String pais = Leer.nextLine();

            System.out.println("Introduzca la fecha de edicion: ");
            String fehaedicion = Leer.nextLine();

            System.out.println("Introduzca el numero de paginas: ");
            String Numeropaginas = Leer.nextLine();


            Libro libro1 = new Libro();
            libro1.setTitulo(titulo);
            libro1.setPrimerNombre(primerNombre);
            libro1.setSegundoNombre(SegundoNombre);
            libro1.setPrimerApellido(primerapellido);
            libro1.setISBN(ISBN);
            libro1.setEdicion(edicion);
            libro1.setCiudad(ciudad);
            libro1.setPais(pais); 
            libro1.setFechasEdicion(fehaedicion);
            libro1.setPaginas(Numeropaginas);
            imprimirlibro(libro1);
            }
        }

    public static void imprimirlibro(Libro libro1) {
        System.out.println("---------------------------------------------------------------------------------------------");
        System.out.println("Titulo: "+libro1.getTitulo());
        System.out.println(libro1.getEdicion()+"a. edicion");
        System.out.println("Autor: "+libro1.getPrimerNombre()+" "+ libro1.getSegundoNombre() +" "+ libro1.getPrimerApellido());
        System.out.println("ISBN: "+libro1.getISBN());
        System.out.println("Editorial: "+Libro.editorial);
        System.out.println(libro1.getCiudad()+", "+ libro1.getPais()+", "+ libro1.getFechasEdicion());
        System.out.println(libro1.getPaginas()+" Paginas");
        System.out.println("---------------------------------------------------------------------------------------------");
    }
}
