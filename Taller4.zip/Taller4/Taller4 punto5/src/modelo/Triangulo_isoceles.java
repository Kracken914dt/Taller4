
package modelo;

public class Triangulo_isoceles {
// ATRIBUTOS DE INSTANCIA 
    private double base;
    private double altura;
    
   //METODO CONSTRUCTOR
   public Triangulo_isoceles(){
       this.base = 0;
       this.altura= 0;

    }
   
   // METODOS GETTER
    public double getBase(){
        return this.base;
    }
    
     public double getAltura(){
        return this.altura;
    }

     
   //METODOS SETTER
    public void setBase(double base){
        this.base = base;
    }
    
    public void setAltura(double altura){
        this.altura = altura;
    }
   
 
    // METODOS MIEMBROS
    public double calcularArea(){
        double area = (this.base * this.altura) / 2;
        return area;
    }
    
    public double longitud_de_lados_iguales(){
        double valor = this.base/2;
        double H = (altura * altura) + (valor * valor);
        double Lados = Math.sqrt(H); 
        return Lados;        
    }
    
    public double calcularPerimetro(){
        return (2 * longitud_de_lados_iguales()) + this.base;
    }
    
    public double valor_del_ángulo_vértice(){
        double angulo;
        double operacion;
        angulo = this.altura/this.longitud_de_lados_iguales();  
            operacion = Math.acos(angulo);
        double a =Math.toDegrees(operacion);
        return a * 2;
    }
  
}
