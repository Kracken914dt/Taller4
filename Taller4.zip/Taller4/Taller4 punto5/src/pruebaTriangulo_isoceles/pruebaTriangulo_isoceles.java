package pruebaTriangulo_isoceles;
import java.util.Scanner;
import modelo.*;
public class pruebaTriangulo_isoceles {
    public static void main(String[] args) {
        Triangulo_isoceles Triangulo1 = new Triangulo_isoceles();
        Scanner Leer = new Scanner(System.in);
        
        System.out.print("Introduzca la base: ");
        double base = Leer.nextDouble();
        Triangulo1.setBase(base);
        System.out.print("Introduzca la altura: ");
        double altura = Leer.nextDouble();
        Triangulo1.setAltura(altura);
        imprimirTriangulo1(Triangulo1);
    }
    
    public static void imprimirTriangulo1(Triangulo_isoceles Triangulo1){
        System.out.println("Base : " + Triangulo1.getBase()+", Altura :"+Triangulo1.getAltura());
        System.out.println("------------------------------------------------------------------------");
        System.out.println("Area: " + Triangulo1.calcularArea());
        System.out.printf("Perimetro: %.2f" , Triangulo1.calcularPerimetro());
        System.out.printf("\nLongitud de sus lados iguales: %.2f", Triangulo1.longitud_de_lados_iguales());
        System.out.printf("\nEl valor del ángulo vértice: %.2f", Triangulo1.valor_del_ángulo_vértice());
    }
}
