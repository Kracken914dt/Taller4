package Modelo;
import java.util.Scanner;

public class Reporte {

   // ATRIBUTOS DE INSTANCIA 
    private double []Mes = new double[12];
    Scanner leer= new Scanner(System.in);
    double suma=0;
    double Tamaño;
    double Meses;
    
    public Reporte(){
        this.Tamaño=12;
    }
  
    
    // METODOS GETTER
    public double getMes(){
        return this.Meses;
    }
    
    public double getSuma(){
        return this.suma;
    }
    
    //METODO SETTER
    public void setMes(double Mes[]){
        this.Mes=Mes;
    }
    
    public void setSuma(double suma){
        this.suma= suma;
    }
    
    // METODOS MIEMBROS
    double promedio;
    public void Leeventa(){
       for (int i=0;i<12;i++){
           System.out.print("Escriba el reporte de venta del mes "+(i+1)+": ");
           Mes[i]=leer.nextDouble();
       }
    }
    public double promedio(){
        double prom;
        for (int i=0;i<Mes.length;i++)
            suma+=Mes[i];
        prom = this.suma/this.Tamaño;
        return  prom;
    }
    public double sumatotal(){
        return suma;
    }
    double mayor,menor;
    int pos=-1;
    public double mayorventa(){
        for (int i=0;i<Mes.length;i++){
            if (Mes[i]>mayor){
                mayor=Mes[i];
                pos=i;
            }
        }
        return (pos+1);
    }
    int pos2=0;
    public double menorVentas(){
        menor=Mes[0];
        for (int g=0;g<Mes.length;g++){
            if (Mes[g]<menor){
                menor=Mes[g];
                pos2=g;
            }
        }
        return (pos2+1);
    }
}
    
 

