package PruebaReporte;
import Modelo.*;

public class PruebaReporte {
    public static void main(String[] args) {
        Reporte InformeMes = new Reporte();
        InformeMes.Leeventa();
        imprimir(InformeMes);
    }
    public static void imprimir(Reporte InformeMes){
        System.out.println("------------------------------------------------------------------");
        System.out.println("El acumulado de ventas del año es: "+InformeMes.sumatotal());
        System.out.printf("El promedio de ventas es: %.2f\n",InformeMes.promedio());
        System.out.println("El mes con mas ventas es:"+InformeMes.mayorventa());
        System.out.println("El mes con menos ventas es:"+InformeMes.menorVentas());
        System.out.println("------------------------------------------------------------------");
    }
}
