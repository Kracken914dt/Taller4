
package Pruebacoche;
import modelo.*;
public class Pruebacoche {
    public static void main(String[] args) {
        
        Coche coche1 = new  Coche();
        coche1.setcolor("negro");
        coche1.setmarca("Ferrari");
        coche1.setmatricula("466hkj");
        coche1.setmodelo("250 GT Berlinetta");
        coche1.setnumero_Caballo(4);
        coche1.setnumero_Puertas(4);
        imprimirCoche(coche1);
        
        Coche coche2 = new  Coche();
        coche2.setcolor("Rojo");
        coche2.setmarca("Audi");
        coche2.setmatricula("678opl");
        coche2.setmodelo("Nuevo A4");
        coche2.setnumero_Caballo(2);
        coche2.setnumero_Puertas(4);
        imprimirCoche2(coche2);
        
        Coche coche3 = new  Coche();
        coche3.setcolor("Azul");
        coche3.setmarca("Mazda");
        coche3.setmatricula("xzq781");
        coche3.setmodelo("MX-5 Miata");
        coche3.setnumero_Caballo(6);
        coche3.setnumero_Puertas(2);
        imprimirCoche3(coche3);
 
    }
    public static void imprimirCoche(Coche coche1){
        System.out.println("El color del coche 1 es: "+coche1.getcolor() + " es de la marca: " + coche1.getmarca() + " Modelo: " + coche1.getmodelo() + " tiene una cantidad de caballos de fuerza de: " + coche1.getnumero_Caballo() + " tiene " +coche1.getnumero_Puertas()+" puertas y una matricula " + coche1.getmatricula());
    }
    
    public static void imprimirCoche2(Coche coche2){
       System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
       System.out.println("El color del coche 2 es: "+coche2.getcolor() + " es de la marca: " + coche2.getmarca() + " Modelo: " + coche2.getmodelo() + " tiene una cantidad de caballos de fuerza de: " + coche2.getnumero_Caballo() + " tiene " +coche2.getnumero_Puertas()+" puertas y una matricula " + coche2.getmatricula());   
    }
    
    public static void imprimirCoche3(Coche coche3){
       System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
       System.out.println("El color del coche 3 es: "+coche3.getcolor() + " es de la marca: " + coche3.getmarca() + " Modelo: " + coche3.getmodelo() + " tiene una cantidad de caballos de fuerza de: " + coche3.getnumero_Caballo() + " tiene " +coche3.getnumero_Puertas()+" puertas y una matricula " + coche3.getmatricula());   
    }
 
}
