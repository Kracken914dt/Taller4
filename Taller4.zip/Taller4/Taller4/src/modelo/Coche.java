package modelo;

public class Coche {
    // ATRIBUTOS DE INSTANCIA 
    private String marca;
    private String color;
    private String modelo;
    private int numero_Caballos;
    private int numero_Puertas;
    private String matricula;
    
    //METODO CONSTRUCTOR SIN PARAMETROS
    public Coche(){
        this.color = "";
        this.numero_Caballos = 0;
        this.numero_Puertas = 0;
        this.marca = "";
        this.matricula = "";
        this.modelo = "";
    } 
    // METODOS GETTER
    public int getnumero_Caballo(){
        return this.numero_Caballos;
    }
    
    public int getnumero_Puertas(){
        return this.numero_Puertas;
    }
    
    public String getmarca() {
        return this.marca;
    }
    
    public String getcolor(){
        return this.color;
    }
    
    public String getmodelo(){
        return this.modelo;
    }
    
    public String getmatricula(){
        return this.matricula;
    }
    
    //METODOS SETTER
    public void setnumero_Caballo(int numero_Caballos){
        this.numero_Caballos = numero_Caballos;
    }
    
    public void setnumero_Puertas(int numero_Puertas){
        this.numero_Puertas = numero_Puertas;
    }
    
    public void setmarca(String marca){
        this.marca = marca;
    }
    
    public void setcolor (String color){
        this.color = color;
    }
    
    public void setmodelo (String modelo){
        this.modelo = modelo;
    }
    
    public void setmatricula (String matricula){
        this.matricula = matricula;
    }

}
    
   

