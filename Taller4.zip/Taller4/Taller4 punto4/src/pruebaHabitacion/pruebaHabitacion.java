package pruebaHabitacion;
import java.util.Scanner;
import modelo.*;
public class pruebaHabitacion {
    public static void main(String[] args) {
        Habitacion habitacion1 = new Habitacion();
        habitacion1.setAltura(8);
        habitacion1.setAncho(10);
        habitacion1.setLargo(20);
        imprimirHabitacion(habitacion1);
        
        Habitacion habitacion2 = new Habitacion();
        Scanner leer = new Scanner(System.in);
        System.out.println("----------------------------");
        System.out.println("Introduzca la altura: ");
        double altura2 = leer.nextDouble();
        habitacion2.setAltura(altura2);
        
        System.out.println("Introduzca el ancho: ");
        double ancho2 = leer.nextDouble();
        habitacion2.setAncho(ancho2);
        
        System.out.println("Introduzca la largo: ");
        double largo2 = leer.nextDouble();
        habitacion2.setLargo(largo2);
        imprimirHabitacion2(habitacion2);
    }
    
    
    
    public static void imprimirHabitacion(Habitacion habitacion1){
        System.out.println("Habitacion 1");
        System.out.println("Largo: "+habitacion1.getLargo()+", Ancho:"+habitacion1.getAncho()+", Alto:"+habitacion1.getAltuta());
        System.out.println("La cantidad de metros cuadrados que se requiere de enchape del piso es: "+habitacion1.calcularEnchape()+" m²");
        System.out.println("La cantidad de metros cuadrados de papel  quese requiere para tapizar son: "+habitacion1.clacularTapizar()+" m²");
    }
    
    public static void imprimirHabitacion2(Habitacion habitacion2){
        System.out.println("Habitacion 2");
        System.out.println("Largo: "+habitacion2.getLargo()+", Ancho:"+habitacion2.getAncho()+", Alto:"+habitacion2.getAltuta());
        System.out.println("La cantidad de metros cuadrados que se requiere de enchape del piso es: "+habitacion2.calcularEnchape()+" m²");
        System.out.println("La cantidad de metros cuadrados de papel  quese requiere para tapizar son: "+habitacion2.clacularTapizar()+" m²");
    }
   
}
