
package modelo;

public class Habitacion {

   // ATRIBUTOS DE INSTANCIA 
    private double largo;
    private double ancho;
    private double altura;
    
    // METODO CONSTRUTOR
    public Habitacion(){
        this.altura = 0;
        this.ancho = 0;
        this.largo = 0;
    }
    
    // METODOS GETTER
    public double getAltuta(){
        return this.altura;
    }
    
    public double getAncho(){
        return this.ancho;
    }
    
    public double getLargo(){
        return this.largo;
    }
    
     //METODOS SETTER
    public void setAltura(double altura){
        this.altura = altura;
    }
    
    public void setAncho(double ancho){
        this.ancho = ancho;
    }
    
    public void setLargo(double largo){
        this.largo = largo;
    }
    // METODOS MIEMBROS
    public double calcularEnchape(){
        double enchape = this.largo * this.ancho;
        return enchape;
    }
    public double clacularTapizar(){
        double tapizar = this.ancho * this.altura;
        return tapizar;
    }
    
    
}

