package PruebaCuenta;
import Modelo.Cuenta;
import java.util.Scanner;

public class PruebaCuenta {
    public static void main(String[] args) {
        int noCuenta1;
        double saldo1;
        String nombreCliente1;
        Cuenta Cuenta = new Cuenta();
        Scanner leer = new Scanner(System.in);
        System.out.println("Introduzca el numero de su cuenta: ");
        noCuenta1 = (int) leer.nextDouble();
        System.out.println("Introduzca el nombre del cliente: ");
        nombreCliente1 = leer.next();
        System.out.println("Introduzca el saldo que tiene: ");
        saldo1 = leer.nextInt();
        
        Cuenta Cuenta1 = new Cuenta();
        Cuenta1.setNoCuenta(noCuenta1);
        Cuenta1.setNombreCliente(nombreCliente1);
        Cuenta1.setSaldo(saldo1);
       
        System.out.println("-----------------");
        System.out.println("1. retirar");
        System.out.println("2. consignar");
        System.out.println("-----------------");
        boolean consignar = false;
        boolean retirar = false;
        while (consignar == false && retirar == false) {            
            int op=leer.nextInt();
        if (op==1) {
            retirar(Cuenta1);
            }
        else if (op==2){
            consignar(Cuenta1);
            }       
        }
    }

    public static void consignar(Cuenta Cuenta1) {
        Scanner leer= new Scanner(System.in);
        System.out.println("Digite la cantidad que desea consignar : ");
        double monto=leer.nextDouble();
        Cuenta1.setSaldo(Cuenta1.getSaldo()+monto);
        System.out.println("Su nuevo saldo es: "+Cuenta1.getSaldo());
    }
    
    public static void retirar(Cuenta Cuenta1) {
        Scanner leer=new Scanner (System.in);
        System.out.println("Digite la cantidad que desea retirar: ");
        double monto=leer.nextDouble();
        Cuenta1.setSaldo(Cuenta1.getSaldo()-monto);
        System.out.println("Su nuevo saldo es: "+Cuenta1.getSaldo());
}   }
