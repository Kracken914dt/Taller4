package Modelo;

public class Cuenta {
    private int noCuenta;
    private String nombreCliente;
    private double saldo;
   
   //METODO CONSTRUCTOR SIN PARAMETROS
    public Cuenta(){
        this.noCuenta = 0;
        this.nombreCliente = "";
        this.saldo = 0;
    }
     // METODOS GETTER
    public int getNoCuenta(){
        return this.noCuenta;
    }
    public String getNombreCliente(){
        return this.nombreCliente;
    }
    public double getSaldo(){
        return this.saldo;
    }
    
    //METODOS SETTER
    public void setNoCuenta(int n){
        this.noCuenta = n;
    }
   
    public void setNombreCliente(String name){
        this.nombreCliente = name;
    }
    
    public void setSaldo(double v){
        this.saldo = v;
    }
    
}
